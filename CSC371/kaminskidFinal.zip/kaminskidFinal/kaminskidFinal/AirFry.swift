//
//  AirFry.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/13/21.
//

import Foundation

var airfry_data = [

    AirFry ( name: "Chicken Breast",
            type: .airfry,
            time: "8",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat airfryer to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in airfryer when ready\n" +
            "4. Cook for 4 minutes on each side\n" +
            "5. After cooking, let sit for 5 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    AirFry ( name: "Medium Steak",
            type: .airfry,
            time: "10`",
            temp: "400",
            author: "Me",
            recipe:
            "1. Preheat airfryer to 400\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in airfryer when ready\n" +
            "4. Cook for 5 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    AirFry ( name: "Pork Chops",
            type: .airfry,
            time: "8",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat airfryer to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in airfryer when ready\n" +
            "4. Cook for 4 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    AirFry ( name: "Hot Dog",
            type: .airfry,
            time: "20",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat airfryer to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in airfryer when ready\n" +
            "4. Cook for 10 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    
]
class AirFry {
    enum `Type` : String {
        case airfry = "airfry"
    }
    
    var name     : String
    var type     : Type
    var time     : String
    var temp     : String
    var author   : String
    var recipe   : String
    var favorite : Bool
    
    init (name: String, type: Type, time: String, temp: String, author: String, recipe: String, favorite: Bool) {
        self.name = name
        self.type = type
        self.time = time
        self.temp = temp
        self.author = author
        self.recipe = recipe
        self.favorite = favorite
    }
}
