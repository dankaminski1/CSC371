//
//  PanFry.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/13/21.
//

import Foundation

var panfry_data = [

    PanFry ( name: "Chicken Breast",
            type: .panfry,
            time: "10",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat pan to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on oiled pan when ready\n" +
            "4. Cook for 5 minutes on each side\n" +
            "5. After cooking, let sit for 5 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    PanFry ( name: "Medium Steak",
            type: .panfry,
            time: "10`",
            temp: "400",
            author: "Me",
            recipe:
            "1. Preheat pan to 400\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on pan when ready\n" +
            "4. Cook for 5 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    PanFry ( name: "Pork Chops",
            type: .panfry,
            time: "8",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat pan to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on oiled pan when ready\n" +
            "4. Cook for 4 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    PanFry ( name: "Hot Dog",
            type: .panfry,
            time: "6",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat pan to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on oiled pan when ready\n" +
            "4. Cook for 3 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    
]
class PanFry {
    enum `Type` : String {
        case panfry = "panfry"
    }
    
    var name     : String
    var type     : Type
    var time     : String
    var temp     : String
    var author   : String
    var recipe   : String
    var favorite : Bool
    
    init (name: String, type: Type, time: String, temp: String, author: String, recipe: String, favorite: Bool) {
        self.name = name
        self.type = type
        self.time = time
        self.temp = temp
        self.author = author
        self.recipe = recipe
        self.favorite = favorite
    }
}
