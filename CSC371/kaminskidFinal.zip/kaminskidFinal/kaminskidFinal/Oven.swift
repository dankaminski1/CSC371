//
//  Oven.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/13/21.
//

import Foundation

var oven_data = [

    Oven ( name: "Chicken Breast",
            type: .oven,
            time: "8",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat oven to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in oven when ready\n" +
            "4. Cook for 4 minutes on each side\n" +
            "5. After cooking, let sit for 5 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    Oven ( name: "Medium Steak",
            type: .oven,
            time: "10`",
            temp: "400",
            author: "Me",
            recipe:
            "1. Preheat oven to 400\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in oven when ready\n" +
            "4. Cook for 5 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    Oven ( name: "Pork Chops",
            type: .oven,
            time: "8",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat oven to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in oven when ready\n" +
            "4. Cook for 4 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    Oven ( name: "Hot Dog",
            type: .oven,
            time: "20",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat oven to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat in oven when ready\n" +
            "4. Cook for 10 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    
]
class Oven {
    enum `Type` : String {
        case oven = "oven"
    }
    
    var name     : String
    var type     : Type
    var time     : String
    var temp     : String
    var author   : String
    var recipe   : String
    var favorite : Bool
    
    init (name: String, type: Type, time: String, temp: String, author: String, recipe: String, favorite: Bool) {
        self.name = name
        self.type = type
        self.time = time
        self.temp = temp
        self.author = author
        self.recipe = recipe
        self.favorite = favorite
    }
}
