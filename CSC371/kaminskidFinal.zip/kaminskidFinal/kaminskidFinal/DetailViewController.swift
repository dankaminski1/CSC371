//
//  DetailViewController.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/12/21.
//

import UIKit

class DetailViewController: UIViewController {

    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    
    var grillRecipe  : Grill?
    var panfryRecipe   : PanFry?
    var ovenRecipe  : Oven?
    var airfryRecipe : AirFry?
    var favoriteRecipe : Favorites?
    
    var favorite : Bool = false
    var author : String = ""
    var method : String = ""
    
    var time  : String = ""
    var temp   : String = ""
    
    
    override func viewWillAppear(_ animated: Bool) {
        if let r = grillRecipe {
            titleLabel.text = r.name
            method = r.type.rawValue
            descriptionLabel.text = r.recipe
            time = r.time
            temp = r.temp
            author = r.author
            favorite = r.favorite
        }
        
        else if let r = panfryRecipe {
            titleLabel.text = r.name
            method = r.type.rawValue
            descriptionLabel.text = r.recipe
            time = r.time
            temp = r.temp
            author = r.author
            favorite = r.favorite
        }
        
        else if let r = ovenRecipe {
            titleLabel.text = r.name
            method = r.type.rawValue
            descriptionLabel.text = r.recipe
            time = r.time
            temp = r.temp
            author = r.author
            favorite = r.favorite
        }
        
        else if let r = airfryRecipe {
            titleLabel.text = r.name
            method = r.type.rawValue
            descriptionLabel.text = r.recipe
            time = r.time
            temp = r.temp
            author = r.author
            favorite = r.favorite
        }
        else if let r = favoriteRecipe {
            titleLabel.text = r.name
            method = r.type.rawValue
            descriptionLabel.text = r.recipe
            time = r.time
            temp = r.temp
            author = r.author
            favorite = r.favorite
        }
        
        setLabels()
    }
    
    
    @IBAction func favoritePressed(_ sender: UIButton) {
        if favorite {
            if let index = favorite_data.index(where: { $0.name == titleLabel.text && $0.type.rawValue == method }) {
                favorite_data.remove(at: index)
            }
            favorite = false
        }
            
        else {
            favorite = true
            favorite_data.append(getData())
        }
        setFavorite()
    }
    
    
    func getData () -> Favorites {
        return Favorites (  name     : titleLabel.text ?? "",
                            type     : Type(rawValue: method)!,
                            time     : time,
                            temp     : temp,
                            author   : author,
                            recipe   : descriptionLabel.text ?? "",
                            favorite : favorite)
    }
    
    func setFavorite () {
        if let r = grillRecipe { r.favorite = favorite }
        else if let r = panfryRecipe { r.favorite = favorite }
        else if let r = ovenRecipe { r.favorite = favorite }
        else if let r = airfryRecipe { r.favorite = favorite }
        else if let r = favoriteRecipe {
            r.favorite = favorite
            let type = r.type.rawValue
            if type == "grill"  {
                if let index = grill_data.index(where: {$0.name == r.name && $0.type.rawValue == type}) {
                    grill_data[index].favorite = favorite
                }
            }
            else if type == "panfry" {
                if let index = panfry_data.index(where: {$0.name == r.name && $0.type.rawValue == type}) {
                    panfry_data[index].favorite = favorite
                }
            }
            else if type == "oven" {
                if let index = oven_data.index(where: {$0.name == r.name && $0.type.rawValue == type}) {
                    oven_data[index].favorite = favorite
                }
            }
            else if type == "airfry" {
                if let index = airfry_data.index(where: {$0.name == r.name && $0.type.rawValue == type}) {
                    airfry_data[index].favorite = favorite
                }
            }
        }
    }
    
    
    func setLabels() {
        if Preferences["degree"]  == "celsius" {
            if let tempInt = Int(temp) {
                temperatureLabel.text = String(convertToCelsius(tempInt)) + "°C"
            }
        }
        else {
            temperatureLabel.text = temp + "°F"
        }
        if let timeInt = Int(time){
            timeLabel.text = time + " minutes"
        }
        }

    func convertToCelsius (_ value : Int) -> Int {
        return Int((Double((value-32))*(5/9)))
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
