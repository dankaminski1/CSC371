//
//  Grill.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/13/21.
//

import Foundation

var grill_data = [

    Grill ( name: "Chicken Breast",
            type: .grill,
            time: "8",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat grill to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on grill when ready\n" +
            "4. Cook for 4 minutes on each side\n" +
            "5. After cooking, let sit for 5 minutes\n" +
            "6. Enjoy.",
            favorite: false),
    
    Grill ( name: "Medium Steak",
            type: .grill,
            time: "10`",
            temp: "400",
            author: "Me",
            recipe:
            "1. Preheat grill to 400\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on grill when ready\n" +
            "4. Cook for 5 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.",
            favorite: false),
    
    Grill ( name: "Pork Chops",
            type: .grill,
            time: "8",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat grill to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on grill when ready\n" +
            "4. Cook for 4 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    Grill ( name: "Hot Dog",
            type: .grill,
            time: "10",
            temp: "350",
            author: "Me",
            recipe:
            "1. Preheat grill to 350\n" +
            "2. Prepare meat for cooking\n" +
            "3. Place meat on grill when ready\n" +
            "4. Cook for 5 minutes on each side\n" +
            "5. After cooking, let sit for 3 minutes\n" +
            "6. Enjoy.\n",
            favorite: false),
    
    
]
class Grill {
    enum `Type` : String {
        case grill = "grill"
    }
    
    var name     : String
    var type     : Type
    var time     : String
    var temp     : String
    var author   : String
    var recipe   : String
    var favorite : Bool
    
    init (name: String, type: Type, time: String, temp: String, author: String, recipe: String, favorite: Bool) {
        self.name = name
        self.type = type
        self.time = time
        self.temp = temp
        self.author = author
        self.recipe = recipe
        self.favorite = favorite
    }
}

