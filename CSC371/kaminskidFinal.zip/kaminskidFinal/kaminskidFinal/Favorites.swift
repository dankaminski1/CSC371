//
//  Favorites.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/13/21.
//

import Foundation

var favorite_data = [Favorites]()

enum `Type` : String {
    case grill    = "grill"
    case panfry   = "panfry"
    case oven     = "oven"
    case airfry   = "airfry"
}

class Favorites {
    var name     : String
    var type     : Type
    var time     : String
    var temp     : String
    var author   : String
    var recipe   : String
    var favorite : Bool
    
    init (name: String, type: Type, time: String, temp: String, author: String, recipe: String, favorite : Bool) {
        self.name = name
        self.type = type
        self.time = time
        self.temp = temp
        self.author = author
        self.recipe = recipe
        self.favorite = favorite
    }
}
