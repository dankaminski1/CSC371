//
//  Preferences.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/13/21.
//

import Foundation

var Preferences = [
    "degree" : "fahrenheit",
]
