//
//  NewRecipeViewController.swift
//  kaminskidFinal
//
//  Created by Natalie  on 3/12/21.
//

import UIKit

var recipe : String = ""
var name   : String = ""
var author : String = ""
var temp   : Int = 350
var time   : Int = 10

class NewRecipeViewController: UIViewController {

    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var temperatureStepper: UIStepper!
    @IBOutlet weak var timeStepper: UIStepper!
    @IBOutlet weak var methodSelection: UISegmentedControl!
    
    
    
    
    @IBAction func inputName(_ sender: UIButton) {
        textInputAlert(title: "New Name", message: "Enter new name", isName: true)
    }
    
    @IBAction func inputAuthor(_ sender: UIButton) {
        textInputAlert(title: "New Author", message: "Enter new author", isName: false)
    }
    
    
    
    @IBAction func saveNewRecipe(_ sender: UIButton) {
        let index = methodSelection.selectedSegmentIndex
        
        if index == 0 {
            if grill_data.index(where: { $0.name == name}) != nil {
                recipeErrorAlert()
            }
            else {
                grill_data.append (Grill (name: name, type: .grill, time: String(time), temp: String(temp), author: author, recipe: recipe, favorite: false))
                recipeSavedAlert()
            }
        }
        else if index == 1 {
            if panfry_data.index(where: { $0.name == name}) != nil {
                recipeErrorAlert()
            }
            else {
                panfry_data.append (PanFry (name: name, type: .panfry, time: String(time), temp: String(temp), author: author, recipe: recipe, favorite: false))
                recipeSavedAlert()
            }
        }
        else if index == 2 {
            if oven_data.index(where: { $0.name == name}) != nil {
                recipeErrorAlert()
            }
            else {
                oven_data.append (Oven (name: name, type: .oven, time: String(time), temp: String(temp), author: author, recipe: recipe, favorite: false))
                recipeSavedAlert()
            }
        }
        
        else if index == 3 {
            if airfry_data.index(where: { $0.name == name}) != nil {
                recipeErrorAlert()
            }
            else {
                airfry_data.append (AirFry (name: name, type: .airfry, time: String(time), temp: String(temp), author: author, recipe: recipe, favorite: false))
                recipeSavedAlert()
            }
        }
        restoreDefaults()
    }

    
    
    @IBAction func discardChanges(_ sender: UIButton) {
        let menu = UIAlertController(title: nil, message: "Lose unsaved changes?", preferredStyle: .actionSheet)
        let discardAction = UIAlertAction(title: "Discard Recipe", style: .destructive) {
            (action) in self.restoreDefaults() }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        menu.addAction(discardAction)
        menu.addAction(cancelAction)
        present(menu, animated: true, completion: nil)
    }
    
    
    @IBAction func tempChanged(_ sender: UIStepper) {
        temp = Int (sender.value)
        if Preferences["degree"]  == "celsius" {
            temperatureLabel.text = String(convertToCelsius(temp)) + "°C"
        }
        else {
            temperatureLabel.text = String(temp) + "°F"
        }
    }
    
    @IBAction func timeChanged(_ sender: UIStepper) {
        time = Int(sender.value)
        timeLabel.text = String(time) + " minutes"
    }
    
    func convertToCelsius (_ value : Int) -> Int {
        return Int((Double((value-32))*(5/9)))
    }
    
    func recipeSavedAlert() {
        let title   = "Enjoy!"
        let message = "Recipe saved"
        let alertController = UIAlertController(title:title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        if Preferences["degree"]  == "celsius" {
            temperatureLabel.text = String(convertToCelsius(temp)) + "°C"
        }
        else {
            temperatureLabel.text = String (temp) + "°F"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    func recipeErrorAlert() {
        let title   = "Name Error"
        let message = "Duplicate recipe names not allowed within cook methods"
        let alertController = UIAlertController(title:title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func textInputAlert (title t : String, message msg : String, isName type : Bool) {
        
        let alert = UIAlertController(title: t, message: msg, preferredStyle: .alert)
        alert.addTextField(configurationHandler: {(textField) in
            textField.placeholder = "Enter text:"
        })
        alert.addAction(UIAlertAction(title: "Done", style: .default, handler: { [weak alert] (_) in
            let text = (alert?.textFields![0].text)!
            if type {
                name = text;
                self.nameLabel.text = text;
            }
            else {
                author = text
                self.authorLabel.text = text
            }
        }))
        self.present(alert, animated: true, completion: nil )
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

func restoreDefaults () {
    name = ""
    author = ""
    recipe = ""
    time = 10
    temp = 350
    nameLabel.text = "Name"
    authorLabel.text = "Author"
    
    if Preferences["degree"]  == "celsius" {
        temperatureLabel.text  = "177°C"
    }
    else {
        temperatureLabel.text  = "350°F"
    }
    
    timeStepper.value = 10
    temperatureStepper.value  = 350
    methodSelection.selectedSegmentIndex = 0
}
}

