import UIKit

//2a function
func rank(key: Int, array: [Int]) -> Int {
    var low = 0
    var high = array.capacity - 1
    while (low <= high){
        let middle = low + (high - low)/2
        if key < array[middle]{
            high = middle - 1
        }
        else if key > array[middle]{
            low = middle + 1
        }
        else{
            return middle
        }
    }
    return -1
}

//2b array
var sortedArray = [1,2,3,4,5,6,7,8,9]

//2b working tests
print(rank(key: 1, array: sortedArray))
print(rank(key: 5, array: sortedArray))
print(rank(key: 9, array: sortedArray))
print(rank(key: 2, array: sortedArray))
print(rank(key: 7, array: sortedArray))



//2b failing tests
print(rank(key: 12, array: sortedArray))
print(rank(key: -12, array: sortedArray))


//3a fraction class added methods
class Fraction {
    var numerator: Int = 0
    var denominator: Int = 1
    
    init(_ numerator: Int, over denominator: Int) {
        self.numerator = numerator
        self.denominator = denominator
    }
    
    init() {}
    
    func setTo(numerator: Int, over denominator: Int) {
        self.numerator = numerator
        self.denominator = denominator
    }
    
    func print() {
        Swift.print("\(numerator)/\(denominator)")
    }
    
    func toDouble() -> Double {
        return Double(numerator) / Double(denominator);
    }
    
    func add(_ f: Fraction) {
        numerator = numerator * f.denominator + denominator * f.numerator
        denominator = denominator * f.denominator
        reduce()
    }
    
    func reduce() {
        var u = abs(numerator)
        var v = denominator
        var r: Int
        while (v != 0) {
            r = u % v; u = v; v = r
        }
        numerator /= u
        denominator /= u
    }
    
    func subtract(_ f: Fraction){
        numerator = numerator * f.denominator - denominator * f.numerator
        denominator = denominator * f.denominator
        reduce()
    }
    func multiply(_ f: Fraction){
        numerator = numerator * f.numerator
        denominator = denominator * f.denominator
        reduce()
    }
    func divide(_ f: Fraction){
        numerator = numerator * f.denominator
        denominator = denominator * f.numerator
        reduce()
    }
    
}

var f1 = Fraction(1, over: 2)
var f2 = Fraction(1, over: 4)

f1.add(f2)
f1.print()
//3b tests for added methods

//subtract tests
var f3 = Fraction(1, over: 2)
var f4 = Fraction(1, over: 5)
f3.subtract(f4)

var f5 = Fraction(3, over: 5)
var f6 = Fraction(1, over: 3)
f5.subtract(f6)

//multiply tests
var f7 = Fraction(1, over: 2)
var f8 = Fraction(1, over: 2)
f7.multiply(f8)

var f9 = Fraction(7, over: 16)
var f10 = Fraction(3, over: 7)
f9.multiply(f10)

//divide tests
var f11 = Fraction(1, over: 3)
var f12 = Fraction(1, over: 5)
f11.divide(f12)

var f13 = Fraction(8, over: 15)
var f14 = Fraction(4, over: 9)
f13.divide(f14)
