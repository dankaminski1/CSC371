//
//  ViewController.swift
//  kaminskidHW4
//
//  Created by Daniel  on 1/31/21.
//

import UIKit

class ViewController: UIViewController {
    var numberArr = [String]()
    var typingNumber = false


    @IBOutlet weak var powerlabel: UILabel!
    @IBOutlet weak var volumelabel: UILabel!
    @IBOutlet weak var channellabel: UILabel!
    
    @IBOutlet weak var powerSwitch: UISwitch!
    @IBOutlet weak var sliderSwitch: UISlider!
    

    @IBOutlet weak var zerobut: UIButton!
    @IBOutlet weak var onebut: UIButton!
    @IBOutlet weak var twobut: UIButton!
    @IBOutlet weak var threebut: UIButton!
    @IBOutlet weak var fourbut: UIButton!
    @IBOutlet weak var fivebut: UIButton!
    @IBOutlet weak var sixbut: UIButton!
    @IBOutlet weak var sevenbut: UIButton!
    @IBOutlet weak var eightbut: UIButton!
    @IBOutlet weak var ninebut: UIButton!
    @IBOutlet weak var chanUpbut: UIButton!
    @IBOutlet weak var chanDownbut: UIButton!
    
    @IBOutlet weak var favoriteChannel: UISegmentedControl!
    
    @IBAction func powerSwitchToggle(_ sender: UISwitch) {
        powerlabel.text = (sender.isOn ? "On" : "Off")
                powerSwitch.setOn(sender.isOn, animated: true)
                if sender.isOn == true {
                    powerlabel.text = "On"
                    sliderSwitch.isEnabled = true
                    zerobut.isEnabled = true
                    onebut.isEnabled = true
                    twobut.isEnabled = true
                    threebut.isEnabled = true
                    fourbut.isEnabled = true
                    fivebut.isEnabled = true
                    sixbut.isEnabled = true
                    sevenbut.isEnabled = true
                    eightbut.isEnabled = true
                    ninebut.isEnabled = true
                    chanUpbut.isEnabled = true
                    chanDownbut.isEnabled = true
                    favoriteChannel.isEnabled = true
                } else {
                    powerlabel.text = "Off"
                    sliderSwitch.isEnabled = false
                    zerobut.isEnabled = false
                    onebut.isEnabled = false
                    twobut.isEnabled = false
                    threebut.isEnabled = false
                    fourbut.isEnabled = false
                    fivebut.isEnabled = false
                    sixbut.isEnabled = false
                    sevenbut.isEnabled = false
                    eightbut.isEnabled = false
                    ninebut.isEnabled = false
                    chanUpbut.isEnabled = false
                    chanDownbut.isEnabled = false
                    favoriteChannel.isEnabled = false
                }
    }
    
    @IBAction func volumeSliderMove(_ sender: UISlider) {
        volumelabel.text = "\(Int(sender.value))"
    }
    
    
    @IBAction func numberButPressed(_ sender: UIButton)
    {
        let number: String = sender.currentTitle!
        
        if numberArr.count == 0 || numberArr.count == 1 {
            numberArr.append(number)
        }
        if numberArr.count == 2 {
            let newChannel = numberArr[0] + numberArr[1]
            
            if newChannel == "00" {
                numberArr.removeAll()
            } else {
                channellabel.text = newChannel
                numberArr.removeAll()
            }
        }
    }
    
    
    @IBAction func addButPressed(_ sender: UIButton)
    {
        let numberLabel = Int(channellabel.text!)
        if numberLabel! + 1 > 99 {
        } else {
            let incNumber = numberLabel! + 1
            channellabel.text = "\(incNumber)"
        }
    }
    
    @IBAction func subButPressed(_ sender: UIButton)
    {
        let numberLabel = Int(channellabel.text!)
           if numberLabel! - 1 < 1 {
           } else {
               let decNumber = numberLabel! - 1
               channellabel.text = "\(decNumber)"
           }
    }
    
    @IBAction func favoriteChannelSelected(_ sender: UISegmentedControl)
    {
        if let name = sender.titleForSegment(at: sender.selectedSegmentIndex){
            channellabel.text = name
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    }
