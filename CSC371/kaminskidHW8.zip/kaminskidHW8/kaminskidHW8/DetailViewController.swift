//
//  DetailViewController.swift
//  kaminskidHW8
//
//  Created by Natalie  on 3/1/21.
//

import UIKit

class DetailViewController: UIViewController {

    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
    @IBOutlet weak var icecreamImage: UIImageView!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    var icecream: IceCream?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let i = icecream{
            titleLabel.text = i.name
            addressLabel.text = "Located at " + i.address
            descriptionLabel.text = i.description
            icecreamImage.image = UIImage(named: i.image)
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
