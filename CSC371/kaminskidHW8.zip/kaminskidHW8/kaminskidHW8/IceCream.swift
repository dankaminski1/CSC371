//
//  IceCream.swift
//  kaminskidHW8
//
//  Created by Natalie  on 3/1/21.
//

import Foundation

let icecream = [

    IceCream(name: "Original Rainbow Cone",
             type: .Blue,
             location: "Beverly",
             address: "9233 S Western Ave",
             description: "For more than 80 years, the awning-covered picnic tables of this South Side ice-cream shop have been packed with locals indulging their sweet tooth. The signature five-flavor Rainbow Cone features layers of chocolate, strawberry, Palmer House (vanilla with cherries and walnuts), pistachio and orange sherbet stacked one on top of the other to form an unbeatable classic.",
             image: "OriginalRainbow"),
    
    IceCream(name: "Pretty Cool Ice Cream",
             type: .Green,
             location: "Logan Square",
             address: "2353 N California Ave",
             description: "Inspired by the memory of standing at the end of her driveway with change in her pocket, waiting on the ice cream truck, Dana Cree opened Pretty Cool Ice Cream in Logan Square. The cute-as-a-button shop slings beautiful popsicles in fascinating flavors. Lick a peanut butter-potato chip custard bar, a plant-based blue moon pop or a strawberry buttermilk bar. If you close your eyes, you can almost hear that classic ice cream truck jingle from your childhood",
             image: "PrettyCool"),
    
    IceCream(name: "Shawn Michelle's Homemade Ice Cream",
             type: .Red,
             location: "Grand Boulevard",
             address: "46 E 47th St",
             description: "The cold case at Yahya and Nataki Muhammad's cheerful Bronzeville scoop shop is packed with hand-churned homemade ice cream in flavors like Jamaican rum raisin, honey cinnamon graham cracker and strawberry supreme. But it won't take long to spot someone devouring the creamery's crown jewel: a generous serving of peach cobbler crowned with melty vanilla ice cream. Once you try this summertime delicacy, prepare to crave it for the rest of your life.",
             image: "ShawnMichelle"),
    
    IceCream(name: "Scooter's Frozen Custard",
             type: .Purple,
             location: "Lake View",
             address: "1658 W Belmont Ave",
             description: "Walk into Scooter’s and disregard the hot dogs, Italian ice and anything else that doesn’t contain the words frozen and custard. Purists should order a cone of vanilla or chocolate and savor every last lick of the cream-laden treat. If you're hankering for something a bit more involved, opt for the banana splice: vanilla custard, banana, chocolate, strawberries, pineapple and nuts. It's big enough to split, but we won't judge if you're selfish.",
             image: "Scooter"),
    
    IceCream(name: "Margie's Candies",
             type: .Blue,
             location: "Logan Square",
             address: "1960 N Western Ave",
             description: "It’s nostalgia that draws people in droves to this kitschy diner and ice-cream parlor. Fancy silver trays, paper doilies and saucers filled with chocolate and caramel sauces bring back fond memories for many who’ve made this place a tradition since it opened in 1921. Equally reminiscent of the good old days are the display shelves, which are crowded with memorabilia from the Beatles, who just had to have some Margie’s ice cream after they played Comiskey.",
             image: "Margie"),
    
    IceCream(name: "Black Dog Gelato",
             type: .Green,
             location: "East Village",
             address: "859 N Damen Ave",
             description: "After peddling her gelato all over town to the city's best chefs and markets, Jessica Oloroso found a fitting home for her first storefront in Ukrainian Village. There, she lures folks with boundary-pushing scoops of gelato such as avocado-cinnamon and sesame-fig-chocolate chip. If you're downtown, check out her stall inside Revival Food Hall for a quick fix over the lunch hour.",
             image: "BlackDog"),
    
    IceCream(name: "The Freeze",
             type: .Red,
             location: "Logan Square",
             address: "2815 W Armitage Ave",
             description: "The Freeze is a vintage time warp, and while there aren’t nearly as many locations of the fast food restaurant (formerly known as Tastee Freez) as once dotted Chicago (there were dozens), you can still find one in Logan Square. Waffle and sugar cones are filled with a high peak of soft serve and dipped in throwback flavors like butterscotch, cotton candy and peanut butter. If you're looking for cheap, no-frills thrills, the Freeze has you covered all summer.",
             image: "TheFreeze"),
    
    IceCream(name: "La Michoacana Premium",
             type: .Purple,
             location: "Lower West Side",
             address: "1855 S Blue Island Ave",
             description: "No summer bucket list is complete without a trip to Pilsen to visit La Michoacana Premium, Chicago's premiere paletería. Upon entering this cheerful shop, you'll be pulled to the display case, which is jam-packed with dozens of paletas in flavors like blackberry, kiwi-strawberry and creamy pistachio. The shop's mangoneada is another fan favorite, blending tangy mango sorbet, hunks of fresh fruit, lime juice and Tajin chili powder.",
             image: "Michoacana"),
    
    IceCream(name: "Scoops",
             type: .Blue,
             location: "Bridgeport",
             address: "608 W 31st St",
             description: "The aroma of fresh waffles pervades the air of this Bridgeport parlor, evidence of the signature house-made waffle cones. Dipped in chocolate and adorned with brightly colored candies, these deep cones are indulgent carriers for both types of chocolate ice cream on offer (though our preference is for the darker variety). Should the ice cream be too rich, you’re in luck: Like all good Italians, these guys focus on espresso, the perfect antidote to your forthcoming sugar crash.",
             image: "Scoop"),
    
    IceCream(name: "Lickity Split",
             type: .Green,
             location: "Edgewater",
             address: "6056 N Broadway",
             description: "With locations in Edgewater and West Rogers Park, this custard shop is a community staple for families and sugar fiends alike. Guests can get their custard by the cone or dish or have it whipped into a sundae or concrete. Spring for the OMG—chocolate or vanilla custard dotted with peanut-butter fudge brownie pieces and a shot of hot fudge. As if that weren't enough, you'll also find cookies, cupcakes and chocolates behind the counter.",
             image: "Lickity"),
]

class IceCream {
    
    enum `Type`: String {
        case Blue = "Blue"
        case Green = "Green"
        case Red = "Red"
        case Purple = "Purple"
    }

var name: String
var type: Type
var location: String
var address: String
var description: String
var image: String

init(name: String, type: Type, location: String, address: String, description: String, image: String){
    self.name = name
    self.type = type
    self.location = location
    self.address = address
    self.description = description
    self.image = image
}
}
